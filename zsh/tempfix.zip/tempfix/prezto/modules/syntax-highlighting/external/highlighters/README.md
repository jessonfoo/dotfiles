zsh-syntax-highlighting / highlighters
======================================

Navigate into the individual highlighters' documentation to see
what styles (`$ZSH_HIGHLIGHT_STYLES` keys) each highlighter defines.

Refer to the [documentation on highlighters](../docs/highlighters.md) for further
information.
